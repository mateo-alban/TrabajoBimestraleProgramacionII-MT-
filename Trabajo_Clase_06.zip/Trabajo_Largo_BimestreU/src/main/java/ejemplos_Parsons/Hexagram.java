package ejemplos_Parsons;

import java.util.Random;

public class Hexagram {
    private String[] lines;
    private Coin[][] coins;
    
    public Hexagram() {
        this.lines = new String[6];
        this.coins = new Coin[6][3]; // 6 lines, 3 coins each
        generateHexagram();
    }
    
    private void generateHexagram() {
        for (int line = 0; line < 6; line++) {
            // Create 3 coins for this line
            Coin[] lineCoins = new Coin[3];
            for (int coin = 0; coin < 3; coin++) {
                lineCoins[coin] = new Coin();
            }
            coins[line] = lineCoins;
            lines[line] = determineHexagramLine(lineCoins);
        }
    }
    
    private String determineHexagramLine(Coin[] lineCoins) {
        int headsCount = 0;
        
        for (Coin coin : lineCoins) {
            if ("heads".equals(coin.getFace())) {
                headsCount++;
            }
        }
        
        if (headsCount == 3) {
            return "OLD_YANG";
        } else if (headsCount == 0) {
            return "OLD_YIN";
        } else if (headsCount == 2) {
            return "YOUNG_YANG";
        } else {
            return "YOUNG_YIN";
        }
    }
    
    public void displayHexagram() {
        System.out.println("Complete I Ching Hexagram:");
        System.out.println("==========================");
        
        // Display from top to bottom (lines 5 to 0)
        for (int i = 5; i >= 0; i--) {
            displaySingleLine(lines[i], i);
        }
        
        displayInterpretation();
    }
    
    private void displaySingleLine(String lineType, int lineNumber) {
        String lineSymbol = "";
        String lineName = "";
        
        switch (lineType) {
            case "OLD_YANG":
                lineSymbol = "\u2500\u2500\u2500 o \u2500\u2500\u2500";
                lineName = "Old Yang (Changing)";
                break;
            case "OLD_YIN":
                lineSymbol = "\u2500\u2500\u2500 x \u2500\u2500\u2500";
                lineName = "Old Yin (Changing)";
                break;
            case "YOUNG_YANG":
                lineSymbol = "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500";
                lineName = "Young Yang";
                break;
            case "YOUNG_YIN":
                lineSymbol = "\u2500\u2500\u2500 \u2500\u2500\u2500";
                lineName = "Young Yin";
                break;
        }
        
        System.out.printf("Line %d: %s - %s%n", lineNumber + 1, lineSymbol, lineName);
    }
    
    private void displayInterpretation() {
        System.out.println("\nHexagram Interpretation:");
        System.out.println("========================");
        
        int changingLines = countChangingLines();
        System.out.println("Number of changing lines: " + changingLines);
        
        if (changingLines > 0) {
            System.out.println("This hexagram will transform into another.");
        }
        
        // Basic interpretation based on line patterns
        System.out.println("\nBasic Meaning:");
        if (countYangLines() > countYinLines()) {
            System.out.println("The hexagram suggests active, creative energy.");
        } else {
            System.out.println("The hexagram suggests receptive, yielding energy.");
        }
    }
    
    private int countChangingLines() {
        int count = 0;
        for (String line : lines) {
            if ("OLD_YANG".equals(line) || "OLD_YIN".equals(line)) {
                count++;
            }
        }
        return count;
    }
    
    private int countYangLines() {
        int count = 0;
        for (String line : lines) {
            if ("OLD_YANG".equals(line) || "YOUNG_YANG".equals(line)) {
                count++;
            }
        }
        return count;
    }
    
    private int countYinLines() {
        int count = 0;
        for (String line : lines) {
            if ("OLD_YIN".equals(line) || "YOUNG_YIN".equals(line)) {
                count++;
            }
        }
        return count;
    }
    
    // Main method to test the Hexagram class
    public static void main(String[] args) {
        Hexagram hexagram = new Hexagram();
        hexagram.displayHexagram();
    }
}