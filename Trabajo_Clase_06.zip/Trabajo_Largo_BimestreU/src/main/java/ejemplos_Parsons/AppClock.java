package ejemplos_Parsons;

public class AppClock {

	public static void main(String[] args) {
		 // Crear objeto Clock
        Clock myClock = new Clock("08:30 AM");

        // Cambiar la hora
        myClock.setTime("09:00 AM");
        System.out.println("\nNueva hora: " + myClock.getTime());

        // Activar la alarma
        myClock.setAlarm();

        // Desactivar la alarma
        myClock.turnAlarmOff();


	}
}
