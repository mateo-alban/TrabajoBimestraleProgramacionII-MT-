package ejemplos_Parsons;

public class CourseRunner {

	public static void main(String[] args) {
		 Course javaCourse = new Course();
		    javaCourse.setName("Java");
		    javaCourse.setNumberOfDays(3);
		    javaCourse.setPricePerPerson(1000.0);
		    System.out.println(javaCourse.getName() +
		    " course lasts " + javaCourse.getNumberOfDays() +
		    " days and costs " + javaCourse.getPricePerPerson());
		    
		    //Aplicamos la funcion 6.4 y mostramos en courserunner
		    double flatRate = 1000.0;
	        int participants = 8;

	        double customCostPerHead = Course.calculateCostPerHead(flatRate, participants);

	        System.out.println("\nCálculo personalizado:");
	        System.out.println("Tarifa plana: $" + flatRate);
	        System.out.println("Participantes: " + participants);
	        System.out.println("Costo por cabeza: $" + customCostPerHead);
	}

}
