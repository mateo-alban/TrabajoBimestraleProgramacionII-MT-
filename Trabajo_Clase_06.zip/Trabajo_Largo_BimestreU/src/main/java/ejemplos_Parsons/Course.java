package ejemplos_Parsons;

public class Course {
	private String name = null;
	private int numberOfDays = 0;
	private double pricePerPerson = 0.0;
	
	//Cronstructor con zero parametros
	
	public Course()
	{
	    this("Unnamed Course", 3, 1000.0);
	}

	/**
	 * Parameterized constructor
	 * @param name The name of the course
	 * @param days The length of the course in days
	 * @param price The cost of the course per person
	 */
	public Course(String name, int days, double price)
	{
	    setName(name);
	    setNumberOfDays(days);
	    setPricePerPerson(price);
	}
	
	
	//Creo geters and setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public int getNumberOfDays() {
		return numberOfDays;
	}
	public void setNumberOfDays(int numberOfDays) {
		if(numberOfDays >=1 && numberOfDays<=10) {
			this.numberOfDays = numberOfDays;
		}else {
		
		}
		
	}
	public double getPricePerPerson() {
		return pricePerPerson;
	}
	public void setPricePerPerson(double pricePerPerson) {
		this.pricePerPerson = pricePerPerson;
	}
	
	//Metodo aniadido en tarea 6.4
    public static double calculateCostPerHead(double flatRate, int participants) {
        if (participants <= 0) {
            return 0;
        }
        return flatRate / participants;
    }
    
    public void showCourseInfo() {
        System.out.println("Curso: " + courseName);
        System.out.println("Participantes: " + numberOfParticipants);
        System.out.println("Costo por persona: $" + costPerHead);
    }
	
}
