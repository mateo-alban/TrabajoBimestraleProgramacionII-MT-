package ejemplos_Parsons;

import java.util.Random;

public class IChingDivination {
    public static void main(String[] args) {
        Coin[] coins = new Coin[3];
        
        // Initialize and throw all coins
        for (int i = 0; i < coins.length; i++) {
            coins[i] = new Coin();
        }
        
        // Display coin results
        System.out.println("Coin throws:");
        for (int i = 0; i < coins.length; i++) {
            System.out.println("Coin " + (i + 1) + ": " + coins[i].getFace());
        }
        
        // Determine the hexagram line
        String lineType = determineHexagramLine(coins);
        displayHexagramLine(lineType);
    }
    
    public static String determineHexagramLine(Coin[] coins) {
        int headsCount = 0;
        int tailsCount = 0;
        
        for (Coin coin : coins) {
            if ("heads".equals(coin.getFace())) {
                headsCount++;
            } else {
                tailsCount++;
            }
        }
        
        if (headsCount == 3) {
            return "OLD_YANG";
        } else if (tailsCount == 3) {
            return "OLD_YIN";
        } else if (headsCount == 2) { // 2 heads, 1 tail
            return "YOUNG_YANG";
        } else { // 2 tails, 1 head
            return "YOUNG_YIN";
        }
    }
    
    public static void displayHexagramLine(String lineType) {
        System.out.println("\nHexagram Line Result:");
        
        switch (lineType) {
            case "OLD_YANG":
                System.out.println("Old Yang line: \u2500\u2500\u2500 o \u2500\u2500\u2500");
                System.out.println("Name: Old Yang (Changing Yang)");
                break;
            case "OLD_YIN":
                System.out.println("Old Yin line: \u2500\u2500\u2500 x \u2500\u2500\u2500");
                System.out.println("Name: Old Yin (Changing Yin)");
                break;
            case "YOUNG_YANG":
                System.out.println("Young Yang line: \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
                System.out.println("Name: Young Yang (Static Yang)");
                break;
            case "YOUNG_YIN":
                System.out.println("Young Yin line: \u2500\u2500\u2500 \u2500\u2500\u2500");
                System.out.println("Name: Young Yin (Static Yin)");
                break;
        }
    }
}