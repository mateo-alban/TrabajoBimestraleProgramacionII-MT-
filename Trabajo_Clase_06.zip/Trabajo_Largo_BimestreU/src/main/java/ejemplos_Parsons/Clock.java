package ejemplos_Parsons;

public class Clock {

	    // Atributos
	    private String currentTime;
	    private boolean alarmState;

	    // Constructor
	    public Clock(String currentTime) {
	        this.currentTime = currentTime;
	        this.alarmState = false; // Por defecto la alarma está apagada
	    }

	    // Métodos
	    public String getTime() {
	        return currentTime;
	    }

	    public void setTime(String newTime) {
	        this.currentTime = newTime;
	    }

	    public void setAlarm() {
	        this.alarmState = true;
	        System.out.println("Alarma activada!");
	    }

	    public void turnAlarmOff() {
	        this.alarmState = false;
	        System.out.println("Alarma desactivada");
	    }

	}
	

