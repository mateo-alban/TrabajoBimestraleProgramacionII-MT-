package ejemplos_Parsons;

import java.util.Random;

import java.util.Random;

public class Coin {
    private String face;
    private Random random;
    
    public Coin() {
        this.random = new Random();
        throwCoin();
    }
    
    public void throwCoin() {
        // 0 for heads, 1 for tails
        boolean isHeads = random.nextBoolean();
        this.face = isHeads ? "heads" : "tails";
    }
    
    public String getFace() {
        return face;
    }
    
    // Method to simulate throwing multiple coins at once
    public static Coin[] throwMultipleCoins(int numberOfCoins) {
        Coin[] coins = new Coin[numberOfCoins];
        for (int i = 0; i < numberOfCoins; i++) {
            coins[i] = new Coin();
        }
        return coins;
    }
}