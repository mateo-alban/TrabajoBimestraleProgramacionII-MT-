package ejemplos_Parsons;

public class DiceRoller {

	public static void main(String[] args) {
		Die die1 = new Die();
		Die die1 = new Die();
		int diceTotal = die.roll() + die2.roll();
		System.out.println("El total del dado es= " + diceTotal);

	}

}
