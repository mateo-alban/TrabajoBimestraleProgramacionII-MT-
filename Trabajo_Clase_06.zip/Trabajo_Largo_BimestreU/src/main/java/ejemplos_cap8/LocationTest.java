package ejemplos_cap8;

public class LocationTest {

	public static void main(String[] args) {
		
		Location clasroom1 = new Location();
		clasroom1.setAddress("Piso 4, new Bank Building");
		clasroom1.setCapacity(20);
		clasroom1.setPricePerDay(300.0);
		
		
		
		Location clasroom2 = new Location();
		clasroom2.setAddress("Seminal universiti florr 5");
		clasroom2.setCapacity(40);
		clasroom2.setPricePerDay(450.0);
		
		Location clasroom3 = new Location();
		clasroom3.setAddress("Universiti computing Lab");
		clasroom3.setCapacity(40);
		clasroom3.setPricePerDay(450.0);
		
		System.out.println("The first class: " + clasroom1);
		System.out.println("the second class: " + clasroom2);
		System.out.println("the third classs: " + clasroom3);
		
		
		boolean isEqual = clasroom2.equals(clasroom3);
		if(isEqual) {
			System.out.println(clasroom2 + "Is equal to the clasrrom" + clasroom3);
		}else {
			System.out.println(clasroom2 + "Is not equal to the clasrrom" + clasroom3);
		}
		

	}
	 
}


