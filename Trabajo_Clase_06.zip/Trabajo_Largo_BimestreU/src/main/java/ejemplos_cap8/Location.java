package ejemplos_cap8;

public class Location extends Object{
	
	 	private String address;
	    private int capacity;
	    private double pricePerDay;

	    public final String getAddress() {
	        return address;
	    }

	    public final void setAddress(String address) {
	        this.address = address;
	    }

	    public final int getCapacity() {
	        return capacity;
	    }

	    public final void setCapacity(int capacity) {
	        this.capacity = capacity;
	    }

	    public final double getPricePerDay() {
	        return pricePerDay;
	    }

	    public final void setPricePerDay(double pricePerDay) {
	        this.pricePerDay = pricePerDay;
	    }

	    @Override
	    public String toString() { 
	        return this.getClass().getSimpleName() + " " + getAddress() + " holds " + getCapacity() + " and costs " + getPricePerDay() + " per day"; 
	    }
	    
	    public boolean equals(Object object) {
	        if (this == object) return true;
	        if (object == null || !(object instanceof Location)) return false;
	        
	        Location other = (Location) object;
	        return getAddress().equals(other.getAddress()) &&
	               getCapacity() == other.getCapacity() &&
	               getPricePerDay() == other.getPricePerDay();
	    }
	    
	    public int hashCode() {
	        int result = 17;
	        result = 31 * result + getAddress().hashCode();
	        result = 31 * result + getCapacity();
	        long temp = Double.doubleToLongBits(getPricePerDay());
	        result = 31 * result + (int) (temp ^ (temp >>> 32));
	        return result;
	    }
}
