package ejemplos_cap8;

public interface Transformable {
	public void switchDimensions();
}
