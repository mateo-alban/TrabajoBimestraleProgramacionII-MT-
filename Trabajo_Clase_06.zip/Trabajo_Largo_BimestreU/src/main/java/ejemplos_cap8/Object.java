package ejemplos_cap8;

public class Object {
    
    public boolean equals(Object obj) {
      
        return this == obj;
    }
   
    public String toString() {
        
        return getClass().getName() + "@" + Integer.toHexString(hashCode());
    }
    
    
    public int hashCode() {
       
        return System.identityHashCode(this);
    }
}