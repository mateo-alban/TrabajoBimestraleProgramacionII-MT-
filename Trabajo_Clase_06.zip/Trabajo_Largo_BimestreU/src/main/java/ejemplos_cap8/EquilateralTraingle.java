package ejemplos_cap8;

import java.awt.Graphics;
import java.awt.Point;

public class EquilateralTraingle extends OneDimensionalShape
{
    public EquilateralTraingle(Point location, int side)
    {
        super(location, side);
    }

    @Override
    public double getArea()
    {
        double side = getDimension();
        // Fórmula: (√3/4) * lado²
        return (Math.sqrt(3) / 4) * side * side;
    }

    @Override
    public void draw(Graphics g)
    {
        int side = getDimension();
        int xLocation = getLocation().x;
        int yLocation = getLocation().y;
        
        // Calcular la altura del triángulo equilátero
        double height = (Math.sqrt(3) / 2) * side;
        
        // Definir los tres puntos del triángulo
        int[] xPoints = {
            xLocation,                         
            xLocation + side,                
            xLocation + side / 2              
        };
        
        int[] yPoints = {
            yLocation + (int)height,           
            yLocation + (int)height,          
            yLocation                          
        };
        
        g.fillPolygon(xPoints, yPoints, 3);
    }
    
    // Método para obtener la altura del triángulo
    public double getHeight()
    {
        return (Math.sqrt(3) / 2) * getDimension();
    }
    
    @Override
    public String toString() {
        return "EquilateralTriangle[location=" + getLocation() + 
               ", side=" + getDimension() + "]";
    }
}