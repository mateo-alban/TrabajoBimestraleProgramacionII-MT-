package ejemplos_cap7;

public class CourseDelivery {
	private Location location;
}
