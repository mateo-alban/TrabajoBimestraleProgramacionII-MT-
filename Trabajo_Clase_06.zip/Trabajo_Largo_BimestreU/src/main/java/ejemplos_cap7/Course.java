package ejemplos_cap7;

public class Course {
	private CourseDelivery[] deliveries;
	private Course prerequisite;
	
	  // an array of modules
    private Module[] modules = new Module[20];
    private int moduleCount = 0;

    public Course(String string, int i, int j) {
		// TODO Auto-generated constructor stub
	}

	// 'addModule' adds a parameter module to the array.
    public void addModule(Module new_module)
    {
        if(moduleCount < modules.length)
        {
            modules[moduleCount] = new_module;
            moduleCount++;
        }
        else
        {
            System.out.println("Cannot add more modules");
        }
    }

    public int getTotalCredits()
    {
        int total = 0;
        for (int i = 0; i < getModuleCount(); i++) {
            total += getModules()[i].getCreditPoints();
        }
        return total;
    }

    public Module[] getModules() {
        return modules;
    }

    public int getModuleCount() {
        return moduleCount;
    }

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
}
