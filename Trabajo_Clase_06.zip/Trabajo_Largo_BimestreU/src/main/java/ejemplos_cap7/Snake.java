package ejemplos_cap7;

public class Snake {
	private BoardSquare start;
    private BoardSquare end;

    public Snake(BoardSquare start, BoardSquare end) {
        this.start = start;
        this.end = end;
    }

    public void movePlayerPiece(PlayerPiece piece) {
        // El jugador cae en la serpiente y baja al final
        piece.setCurrentPosition(end);
    }
}
