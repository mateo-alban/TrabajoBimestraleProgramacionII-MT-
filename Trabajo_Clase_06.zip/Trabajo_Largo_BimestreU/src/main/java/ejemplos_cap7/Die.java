package ejemplos_cap7;

public class Die {
	//Tarea completada
	   public int roll() {
	        return (int) (Math.random() * 6) + 1;
	    }
}

