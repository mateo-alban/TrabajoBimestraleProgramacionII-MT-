package ejemplos_cap7;

public class NotGate {
	 public int getOutput(int input1){
	        if(input1 == 1){
	            return 0;
	        } else {
	         return 1;
	        }
	    }
}

