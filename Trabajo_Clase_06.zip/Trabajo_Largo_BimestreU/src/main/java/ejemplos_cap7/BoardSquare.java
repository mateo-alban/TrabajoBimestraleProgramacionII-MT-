package ejemplos_cap7;

public class BoardSquare {

    private int position;
    private Ladder ladder;
    private Snake snake;

    public BoardSquare(int position) {
        this.position = position;
    }

    public int getPosition() {
        return position;
    }

    public void addLadder(Ladder ladder) {
        
        if (this.snake != null) {
            throw new IllegalStateException("This square already has a snake.");
        }
        this.ladder = ladder;
    }

    public void addSnake(Snake snake) {
        if (this.ladder != null) {
            throw new IllegalStateException("This square already has a ladder.");
        }
        this.snake = snake;
    }

    public void movePlayerPiece(PlayerPiece piece) {
        if (ladder != null) {
            ladder.movePlayerPiece(piece);
        } else if (snake != null) {
            snake.movePlayerPiece(piece);
        } else {
            piece.setCurrentPosition(this);
        }
    }
    
}
