package ejemplos_cap7;

public class Ladder {

    private BoardSquare start;
    private BoardSquare end;

    public Ladder(BoardSquare start, BoardSquare end) {
        this.start = start;
        this.end = end;
    }

    public void movePlayerPiece(PlayerPiece piece) {
        // El jugador sube por la escalera hacia el final
        piece.setCurrentPosition(end);
    }
}
