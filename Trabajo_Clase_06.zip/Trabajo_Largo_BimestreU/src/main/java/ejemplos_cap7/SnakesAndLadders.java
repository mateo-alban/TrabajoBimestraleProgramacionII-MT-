package ejemplos_cap7;

public class SnakesAndLadders {
	//Tarea completa
	private GameBoard board;

    public SnakesAndLadders() {
        board = new GameBoard();
    }

    public void play() {
        PlayerPiece counter = new PlayerPiece("Red");
        counter.setCurrentPosition(board.getStartSquare());

        while (counter.getCurrentPosition().getPosition() < GameBoard.MAX_SQUARES) {
            board.movePlayerPiece(counter);
        }
        System.out.println(counter.getColor() + " counter finished on " +
                          counter.getCurrentPosition().getPosition());
    }

    public static void main(String[] args) {
        SnakesAndLadders myGame = new SnakesAndLadders();
        myGame.play();
    }
        
}
