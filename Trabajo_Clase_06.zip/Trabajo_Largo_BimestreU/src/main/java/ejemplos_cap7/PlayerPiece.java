package ejemplos_cap7;

public class PlayerPiece {
	
	  	private String color;
	    private BoardSquare currentPosition;

	    public PlayerPiece(String color) {
	        this.color = color;
	    }

	    public void moveTo(BoardSquare square) {
	        this.currentPosition = square;
	    }

	    public BoardSquare getCurrentPosition() {
	        return currentPosition;
	    }

	    public void setCurrentPosition(BoardSquare square) {
	        this.currentPosition = square;
	    }

	    public String getColor() {
	        return color;
	    }

		public void setCurrentPosition(BoardSquare end) {
			// TODO Auto-generated method stub
			
		}
}
