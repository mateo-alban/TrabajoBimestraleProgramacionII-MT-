package Teoricos_10;

public class Deposito extends Transaccion {
    private double monto;
    
    @Override
    public void ejecutar() {
        // Lógica para depositar dinero
    }
    
    public double obtenerMonto() {
        return monto;
    }
    
    public void establecerMonto(double monto) {
        this.monto = monto;
    }
}