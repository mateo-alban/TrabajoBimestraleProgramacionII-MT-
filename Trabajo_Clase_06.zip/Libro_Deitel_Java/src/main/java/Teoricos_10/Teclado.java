package Teoricos_10;

public class Teclado {
    private Scanner scanner;
    
    public Teclado() {
        scanner = new Scanner(System.in);
    }
    
    public int obtenerEntrada() {
        return scanner.nextInt();
    }
    
    public double obtenerEntradaDouble() {
        return scanner.nextDouble();
    }
}