package Teoricos_10;

public class BaseDatosBanco {
    public boolean autenticar(int numeroCuenta, int nip) {
        // Lógica de autenticación
        return true;
    }
    
    public double obtenerSaldoDisponible(int numeroCuenta) {
        // Lógica para obtener saldo disponible
        return 0.0;
    }
    
    public double obtenerSaldoTotal(int numeroCuenta) {
        // Lógica para obtener saldo total
        return 0.0;
    }
    
    public void abonar(int numeroCuenta, double monto) {
        // Lógica para abonar
    }
    
    public void cargar(int numeroCuenta, double monto) {
        // Lógica para cargar
    }
}