package Teoricos_10;

public class PruebaPolimorfismo
{
    public static void main( String args[] )
    {
        EmpleadoPorComision3 empleadoPorComision = new EmpleadoPorComision3(
            "Sue", "Jones", "222-22-2222", 10000, .06 );
            
        EmpleadoBaseMasComision4 empleadoBaseMasComision =
            new EmpleadoBaseMasComision4(
                "Bob", "Lewis", "333-33-3333", 5000, .04, 300 );
                
        System.out.printf("%s %s:\n\n%s\n\n",
            "Llamada a toString de EmpleadoPorComision3 con referencia de superclase",
            "a un objeto de la superclase", empleadoPorComision.toString() );
            
        System.out.printf("%s %s:\n\n%s\n\n",
            "Llamada a toString de EmpleadoBaseMasComision4 con referencia",
            "de subclase a un objeto de la subclase",
            empleadoBaseMasComision.toString() );

        EmpleadoPorComision3 empleadoPorComision2 =
            empleadoBaseMasComision;
        System.out.printf("%s %s:\n\n%s\n",
            "Llamada a toString de EmpleadoBaseMasComision4 con referencia de superclase",
            "a un objeto de la subclase", empleadoPorComision2.toString() );
    }
}