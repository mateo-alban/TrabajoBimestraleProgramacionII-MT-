package Teoricos_10;

public class ATM {
    private boolean usuarioAutenticado = false;
    
    // Métodos de la clase ATM
    public void autenticarUsuario() {
        // Lógica de autenticación
    }
    
    public void mostrarMenuPrincipal() {
        // Lógica del menú principal
    }
    
    public void ejecutarTransaccion() {
        // Lógica para ejecutar transacciones
    }
}