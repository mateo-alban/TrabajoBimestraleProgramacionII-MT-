package Teoricos_10;

public class Tetraedro extends FiguraTridimensional {
    private double arista;
    
    public Tetraedro() {
        this(1.0);
    }
    
    public Tetraedro(double arista) {
        this(arista, "morado", true);
    }
    
    public Tetraedro(double arista, String color, boolean relleno) {
        super(color, relleno);
        setArista(arista);
    }
    
    public double getArista() {
        return arista;
    }
    
    public void setArista(double arista) {
        if (arista <= 0) {
            throw new IllegalArgumentException("La arista debe ser positiva");
        }
        this.arista = arista;
    }
    
    @Override
    public double obtenerArea() {
        return Math.sqrt(3) * arista * arista;
    }
    
    @Override
    public double obtenerVolumen() {
        return (Math.pow(arista, 3)) / (6 * Math.sqrt(2));
    }
    
    @Override
    public String obtenerDescripcion() {
        return String.format("Tetraedro - Arista: %.2f, Area Superficial: %.2f, Volumen: %.2f", 
                           arista, obtenerArea(), obtenerVolumen());
    }
    
    @Override
    public String toString() {
        return String.format("Tetraedro[%s, arista=%.2f]", super.toString(), arista);
    }
}