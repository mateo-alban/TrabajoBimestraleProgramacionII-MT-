package Teoricos_10;

public class SistemaNominaModificado {
    public static void main(String[] args) {
        // Crear arreglo de empleados con todas las clases concretas
        Empleado[] empleados = {
            new EmpleadoAsalariado("Juan", "Pérez", "111-11-1111", 800.00),
            new EmpleadoPorHoras("María", "Gómez", "222-22-2222", 16.75, 40),
            new EmpleadoPorComision("Carlos", "López", "333-33-3333", 10000, .06),
            new TrabajadorPorPiezas("Ana", "Rodríguez", "444-44-4444", 2.50, 200),
            new EmpleadoPorHoras("Pedro", "Martínez", "555-55-5555", 20.00, 45),
            new TrabajadorPorPiezas("Laura", "Hernández", "666-66-6666", 3.75, 150)
        };

        System.out.println("SISTEMA DE NÓMINA MODIFICADO");
        System.out.println("============================\n");

        // Procesar cada elemento en el arreglo de forma genérica
        for (Empleado empleadoActual : empleados) {
            System.out.println(empleadoActual); // Invoca toString
            System.out.printf("Ingresos: $%,.2f%n%n", empleadoActual.ingresos());
        }

        // Obtener el tipo de cada objeto en el arreglo de empleados
        System.out.println("RESUMEN POR TIPO DE EMPLEADO:");
        System.out.println("==============================");
        
        for (int j = 0; j < empleados.length; j++) {
            System.out.printf("Empleado %d es un %s%n", 
                j, empleados[j].getClass().getName());
        }
    }
}