package Teoricos_10;

public class SolicitudSaldo extends Transaccion {
    @Override
    public void ejecutar() {
        // Lógica para mostrar saldo
    }
}
