package Teoricos_10;

public class RanuraDeposito {
    public boolean seRecibioSobre() {
        // Lógica para verificar si se recibió un sobre
        return true;
    }
}