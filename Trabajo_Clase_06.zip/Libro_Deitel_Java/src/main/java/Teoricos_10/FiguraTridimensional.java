package Teoricos_10;

public abstract class FiguraTridimensional extends Figura {
    
    public FiguraTridimensional() {
        super();
    }
    
    public FiguraTridimensional(String color, boolean relleno) {
        super(color, relleno);
    }
    
    public abstract double obtenerArea();
    public abstract double obtenerVolumen();
    
    @Override
    public String obtenerDescripcion() {
        return String.format("Figura Tridimensional - Area: %.2f, Volumen: %.2f", 
                           obtenerArea(), obtenerVolumen());
    }
}