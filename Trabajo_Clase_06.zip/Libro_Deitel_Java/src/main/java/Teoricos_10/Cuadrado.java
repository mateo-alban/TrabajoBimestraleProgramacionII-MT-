package Teoricos_10;

public class Cuadrado extends FiguraBidimensional {
    private double lado;
    
    public Cuadrado() {
        this(1.0);
    }
    
    public Cuadrado(double lado) {
        this(lado, "azul", true);
    }
    
    public Cuadrado(double lado, String color, boolean relleno) {
        super(color, relleno);
        setLado(lado);
    }
    
    public double getLado() {
        return lado;
    }
    
    public void setLado(double lado) {
        if (lado <= 0) {
            throw new IllegalArgumentException("El lado debe ser positivo");
        }
        this.lado = lado;
    }
    
    @Override
    public double obtenerArea() {
        return lado * lado;
    }
    
    public double obtenerPerimetro() {
        return 4 * lado;
    }
    
    @Override
    public String obtenerDescripcion() {
        return String.format("Cuadrado - Lado: %.2f, Area: %.2f, Perímetro: %.2f", 
                           lado, obtenerArea(), obtenerPerimetro());
    }
    
    @Override
    public String toString() {
        return String.format("Cuadrado[%s, lado=%.2f]", super.toString(), lado);
    }
}