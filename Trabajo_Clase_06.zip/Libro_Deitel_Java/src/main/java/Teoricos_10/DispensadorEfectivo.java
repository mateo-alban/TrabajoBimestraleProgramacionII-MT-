package Teoricos_10;

public class DispensadorEfectivo {
    private int cuenta = 500;
    
    public void dispensarEfectivo(double monto) {
        // Lógica para dispensar efectivo
    }
    
    public boolean haySuficienteEfectivoDisponible(double monto) {
        return monto <= cuenta;
    }
}