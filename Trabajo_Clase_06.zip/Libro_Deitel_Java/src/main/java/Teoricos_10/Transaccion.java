package Teoricos_10;

public abstract class Transaccion {
    private int numeroCuenta;
    
    public int obtenerNumeroCuenta() {
        return numeroCuenta;
    }
    
    public void establecerNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }
    
    public abstract void ejecutar();
}