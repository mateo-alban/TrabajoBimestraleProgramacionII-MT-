package Teoricos_10;

public class PruebaJerarquiaFiguras {
    public static void main(String[] args) {
        // Crear arreglo de referencias Figura
        Figura[] figuras = {
            new Circulo(5.0, "rojo", true),
            new Cuadrado(4.0, "azul", false),
            new Triangulo(3.0, 4.0, "verde", true),
            new Cubo(3.0, "amarillo", true),
            new Esfera(2.5, "naranja", true),
            new Tetraedro(2.0, "morado", false),
            new Circulo(2.0),
            new Cuadrado(5.0)
        };
        
        System.out.println("JERARQUÍA DE FIGURAS");
        System.out.println("====================\n");
        
        // Procesar cada figura en el arreglo
        for (Figura figura : figuras) {
            System.out.println("Descripción: " + figura.obtenerDescripcion());
            System.out.println("Detalles: " + figura.toString());
            
            // Determinar el tipo de figura
            if (figura instanceof FiguraBidimensional) {
                FiguraBidimensional figura2D = (FiguraBidimensional) figura;
                System.out.printf("ÁREA: %.2f%n", figura2D.obtenerArea());
            } 
            else if (figura instanceof FiguraTridimensional) {
                FiguraTridimensional figura3D = (FiguraTridimensional) figura;
                System.out.printf("ÁREA SUPERFICIAL: %.2f%n", figura3D.obtenerArea());
                System.out.printf("VOLUMEN: %.2f%n", figura3D.obtenerVolumen());
            }
            
            System.out.println("----------------------------------------");
        }
        
        // Resumen estadístico
        System.out.println("\nRESUMEN ESTADÍSTICO:");
        System.out.println("====================");
        
        int contador2D = 0;
        int contador3D = 0;
        double areaTotal2D = 0;
        double areaTotal3D = 0;
        double volumenTotal = 0;
        
        for (Figura figura : figuras) {
            if (figura instanceof FiguraBidimensional) {
                contador2D++;
                areaTotal2D += ((FiguraBidimensional) figura).obtenerArea();
            } 
            else if (figura instanceof FiguraTridimensional) {
                contador3D++;
                FiguraTridimensional figura3D = (FiguraTridimensional) figura;
                areaTotal3D += figura3D.obtenerArea();
                volumenTotal += figura3D.obtenerVolumen();
            }
        }
        
        System.out.printf("Figuras Bidimensionales: %d%n", contador2D);
        System.out.printf("Área total 2D: %.2f%n", areaTotal2D);
        System.out.printf("Figuras Tridimensionales: %d%n", contador3D);
        System.out.printf("Área total 3D: %.2f%n", areaTotal3D);
        System.out.printf("Volumen total: %.2f%n", volumenTotal);
    }
}