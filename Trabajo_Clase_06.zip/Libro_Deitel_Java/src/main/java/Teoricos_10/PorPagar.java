package Teoricos_10;

public interface PorPagar {
	double obtenerMontoPago();
}
