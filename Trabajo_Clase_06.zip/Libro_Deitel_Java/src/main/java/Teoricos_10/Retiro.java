package Teoricos_10;

public class Retiro extends Transaccion {
    private double monto;
    
    @Override
    public void ejecutar() {
        // Lógica para retirar dinero
    }
    
    public double obtenerMonto() {
        return monto;
    }
    
    public void establecerMonto(double monto) {
        this.monto = monto;
    }
}