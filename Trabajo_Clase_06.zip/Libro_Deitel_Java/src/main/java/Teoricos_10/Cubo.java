package Teoricos_10;

public class Cubo extends FiguraTridimensional {
    private double lado;
    
    public Cubo() {
        this(1.0);
    }
    
    public Cubo(double lado) {
        this(lado, "amarillo", true);
    }
    
    public Cubo(double lado, String color, boolean relleno) {
        super(color, relleno);
        setLado(lado);
    }
    
    public double getLado() {
        return lado;
    }
    
    public void setLado(double lado) {
        if (lado <= 0) {
            throw new IllegalArgumentException("El lado debe ser positivo");
        }
        this.lado = lado;
    }
    
    @Override
    public double obtenerArea() {
        return 6 * lado * lado;
    }
    
    @Override
    public double obtenerVolumen() {
        return lado * lado * lado;
    }
    
    @Override
    public String obtenerDescripcion() {
        return String.format("Cubo - Lado: %.2f, Area Superficial: %.2f, Volumen: %.2f", 
                           lado, obtenerArea(), obtenerVolumen());
    }
    
    @Override
    public String toString() {
        return String.format("Cubo[%s, lado=%.2f]", super.toString(), lado);
    }
}