package Teoricos_10;

public class Pantalla {
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
    
    public void mostrarMensajeLinea(String mensaje) {
        System.out.print(mensaje);
    }
}
