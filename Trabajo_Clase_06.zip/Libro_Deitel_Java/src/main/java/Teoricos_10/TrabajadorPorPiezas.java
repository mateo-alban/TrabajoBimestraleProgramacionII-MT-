package Teoricos_10;

public class TrabajadorPorPiezas extends Empleado {
    private double sueldoPorPieza;
    private int piezasProducidas;

    public TrabajadorPorPiezas(String nombre, String apellido, String numeroSeguroSocial,
                              double sueldoPorPieza, int piezasProducidas) {
        super(nombre, apellido, numeroSeguroSocial);
        
        if (sueldoPorPieza < 0.0) {
            throw new IllegalArgumentException("El sueldo por pieza debe ser >= 0.0");
        }
        
        if (piezasProducidas < 0) {
            throw new IllegalArgumentException("Las piezas producidas deben ser >= 0");
        }
        
        this.sueldoPorPieza = sueldoPorPieza;
        this.piezasProducidas = piezasProducidas;
    }

    public void establecerSueldoPorPieza(double sueldoPorPieza) {
        if (sueldoPorPieza < 0.0) {
            throw new IllegalArgumentException("El sueldo por pieza debe ser >= 0.0");
        }
        this.sueldoPorPieza = sueldoPorPieza;
    }

    public double obtenerSueldoPorPieza() {
        return sueldoPorPieza;
    }

    public void establecerPiezasProducidas(int piezasProducidas) {
        if (piezasProducidas < 0) {
            throw new IllegalArgumentException("Las piezas producidas deben ser >= 0");
        }
        this.piezasProducidas = piezasProducidas;
    }

    public int obtenerPiezasProducidas() {
        return piezasProducidas;
    }

    @Override
    public double ingresos() {
        return sueldoPorPieza * piezasProducidas;
    }

    @Override
    public String toString() {
        return String.format("%s: %s%n%s: $%,.2f; %s: %d",
                "Trabajador por piezas", super.toString(),
                "sueldo por pieza", obtenerSueldoPorPieza(),
                "piezas producidas", obtenerPiezasProducidas());
    }

	@Override
	public double obtenerMontoPago() {
		// TODO Auto-generated method stub
		return 0;
	}
}