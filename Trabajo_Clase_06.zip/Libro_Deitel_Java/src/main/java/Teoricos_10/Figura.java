package Teoricos_10;

public abstract class Figura {
    private String color;
    private boolean relleno;
    
    public Figura() {
        this("negro", true);
    }
    
    public Figura(String color, boolean relleno) {
        this.color = color;
        this.relleno = relleno;
    }
    
    public String getColor() {
        return color;
    }
    
    public void setColor(String color) {
        this.color = color;
    }
    
    public boolean estaRelleno() {
        return relleno;
    }
    
    public void setRelleno(boolean relleno) {
        this.relleno = relleno;
    }
    
    public abstract String obtenerDescripcion();
    
    @Override
    public String toString() {
        return String.format("Figura[color=%s, relleno=%s]", color, relleno);
    }
}