package Teoricos_10;

public class Circulo extends FiguraBidimensional {
    private double radio;
    
    public Circulo() {
        this(1.0);
    }
    
    public Circulo(double radio) {
        this(radio, "rojo", true);
    }
    
    public Circulo(double radio, String color, boolean relleno) {
        super(color, relleno);
        setRadio(radio);
    }
    
    public double getRadio() {
        return radio;
    }
    
    public void setRadio(double radio) {
        if (radio <= 0) {
            throw new IllegalArgumentException("El radio debe ser positivo");
        }
        this.radio = radio;
    }
    
    @Override
    public double obtenerArea() {
        return Math.PI * radio * radio;
    }
    
    public double obtenerPerimetro() {
        return 2 * Math.PI * radio;
    }
    
    @Override
    public String obtenerDescripcion() {
        return String.format("Círculo - Radio: %.2f, Area: %.2f, Perímetro: %.2f", 
                           radio, obtenerArea(), obtenerPerimetro());
    }
    
    @Override
    public String toString() {
        return String.format("Circulo[%s, radio=%.2f]", super.toString(), radio);
    }
}