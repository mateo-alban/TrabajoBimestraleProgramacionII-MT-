package Teoricos_10;

public class Esfera extends FiguraTridimensional {
    private double radio;
    
    public Esfera() {
        this(1.0);
    }
    
    public Esfera(double radio) {
        this(radio, "naranja", true);
    }
    
    public Esfera(double radio, String color, boolean relleno) {
        super(color, relleno);
        setRadio(radio);
    }
    
    public double getRadio() {
        return radio;
    }
    
    public void setRadio(double radio) {
        if (radio <= 0) {
            throw new IllegalArgumentException("El radio debe ser positivo");
        }
        this.radio = radio;
    }
    
    @Override
    public double obtenerArea() {
        return 4 * Math.PI * radio * radio;
    }
    
    @Override
    public double obtenerVolumen() {
        return (4.0 / 3.0) * Math.PI * Math.pow(radio, 3);
    }
    
    @Override
    public String obtenerDescripcion() {
        return String.format("Esfera - Radio: %.2f, Area Superficial: %.2f, Volumen: %.2f", 
                           radio, obtenerArea(), obtenerVolumen());
    }
    
    @Override
    public String toString() {
        return String.format("Esfera[%s, radio=%.2f]", super.toString(), radio);
    }
}