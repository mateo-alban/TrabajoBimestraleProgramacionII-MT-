package Teoricos_10;

public abstract class FiguraBidimensional extends Figura {
    
    public FiguraBidimensional() {
        super();
    }
    
    public FiguraBidimensional(String color, boolean relleno) {
        super(color, relleno);
    }
    
    public abstract double obtenerArea();
    
    @Override
    public String obtenerDescripcion() {
        return String.format("Figura Bidimensional - Area: %.2f", obtenerArea());
    }
}
