package Teoricos_10;

public class Triangulo extends FiguraBidimensional {
    private double base;
    private double altura;
    
    public Triangulo() {
        this(1.0, 1.0);
    }
    
    public Triangulo(double base, double altura) {
        this(base, altura, "verde", true);
    }
    
    public Triangulo(double base, double altura, String color, boolean relleno) {
        super(color, relleno);
        setBase(base);
        setAltura(altura);
    }
    
    public double getBase() {
        return base;
    }
    
    public void setBase(double base) {
        if (base <= 0) {
            throw new IllegalArgumentException("La base debe ser positiva");
        }
        this.base = base;
    }
    
    public double getAltura() {
        return altura;
    }
    
    public void setAltura(double altura) {
        if (altura <= 0) {
            throw new IllegalArgumentException("La altura debe ser positiva");
        }
        this.altura = altura;
    }
    
    @Override
    public double obtenerArea() {
        return (base * altura) / 2;
    }
    
    public double obtenerHipotenusa() {
        return Math.sqrt(base * base + altura * altura);
    }
    
    public double obtenerPerimetro() {
        return base + altura + obtenerHipotenusa();
    }
    
    @Override
    public String obtenerDescripcion() {
        return String.format("Triángulo - Base: %.2f, Altura: %.2f, Area: %.2f", 
                           base, altura, obtenerArea());
    }
    
    @Override
    public String toString() {
        return String.format("Triangulo[%s, base=%.2f, altura=%.2f]", 
                           super.toString(), base, altura);
    }
}