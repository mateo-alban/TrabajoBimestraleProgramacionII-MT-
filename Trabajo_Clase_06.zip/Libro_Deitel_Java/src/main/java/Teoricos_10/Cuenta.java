package Teoricos_10;

public class Cuenta {
    private int numeroCuenta;
    private int nip;
    private double saldoDisponible;
    private double saldoTotal;
    
    public boolean validarNIP(int nipUsuario) {
        return this.nip == nipUsuario;
    }
    
    public double obtenerSaldoDisponible() {
        return saldoDisponible;
    }
    
    public double obtenerSaldoTotal() {
        return saldoTotal;
    }
    
    public void abonar(double monto) {
        saldoDisponible += monto;
        saldoTotal += monto;
    }
    
    public void cargar(double monto) {
        saldoDisponible -= monto;
        saldoTotal -= monto;
    }
    
    // Getters y Setters
    public int obtenerNumeroCuenta() {
        return numeroCuenta;
    }
    
    public void establecerNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }
    
    public int obtenerNip() {
        return nip;
    }
    
    public void establecerNip(int nip) {
        this.nip = nip;
    }
}