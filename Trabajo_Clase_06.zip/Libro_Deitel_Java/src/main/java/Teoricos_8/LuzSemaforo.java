package Teoricos_8;

public enum LuzSemaforo {
    ROJO(30),
    VERDE(45),
    AMARILLO(5);
    
    private final int duracion;
    
    private LuzSemaforo(int duracion) {
        this.duracion = duracion;
    }
    
    public int getDuracion() {
        return duracion;
    }
}