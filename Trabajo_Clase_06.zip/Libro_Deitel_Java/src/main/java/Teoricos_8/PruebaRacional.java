package Teoricos_8;

public class PruebaRacional {
    public static void main(String[] args) {
        Racional r1 = new Racional(1, 2);
        Racional r2 = new Racional(3, 4);
        
        System.out.println("r1 = " + r1);
        System.out.println("r2 = " + r2);
        System.out.println("Suma: " + r1.sumar(r2));
        System.out.println("Resta: " + r1.restar(r2));
        System.out.println("Multiplicación: " + r1.multiplicar(r2));
        System.out.println("División: " + r1.dividir(r2));
        System.out.println("Decimal (4 dígitos): " + r1.aFormaDecimal(4));
        
        // Prueba de reducción automática
        Racional r3 = new Racional(2, 4);
        System.out.println("2/4 reducido: " + r3);
    }
}