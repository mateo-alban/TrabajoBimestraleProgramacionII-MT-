package Teoricos_8;

import java.util.Scanner;

public class TresEnRaya {
    private int[][] tablero;
    private int jugadorActual;
    
    public TresEnRaya() {
        tablero = new int[3][3];
        jugadorActual = 1;
    }
    
    public void jugar() {
        Scanner scanner = new Scanner(System.in);
        boolean juegoTerminado = false;
        
        System.out.println("¡Bienvenido al Tres en Raya!");
        mostrarTablero();
        
        while (!juegoTerminado) {
            System.out.printf("Jugador %d, ingresa fila y columna (0-2): ", jugadorActual);
            int fila = scanner.nextInt();
            int columna = scanner.nextInt();
            
            if (movimientoValido(fila, columna)) {
                tablero[fila][columna] = jugadorActual;
                mostrarTablero();
                
                if (hayGanador()) {
                    System.out.printf("¡Jugador %d gana!%n", jugadorActual);
                    juegoTerminado = true;
                } else if (tableroLleno()) {
                    System.out.println("¡Empate!");
                    juegoTerminado = true;
                } else {
                    jugadorActual = (jugadorActual == 1) ? 2 : 1;
                }
            } else {
                System.out.println("Movimiento inválido. Intenta de nuevo.");
            }
        }
        scanner.close();
    }
    
    private boolean movimientoValido(int fila, int columna) {
        return fila >= 0 && fila < 3 && columna >= 0 && columna < 3 && tablero[fila][columna] == 0;
    }
    
    private boolean hayGanador() {
        // Verificar filas
        for (int i = 0; i < 3; i++) {
            if (tablero[i][0] != 0 && tablero[i][0] == tablero[i][1] && tablero[i][1] == tablero[i][2]) {
                return true;
            }
        }
        
        // Verificar columnas
        for (int j = 0; j < 3; j++) {
            if (tablero[0][j] != 0 && tablero[0][j] == tablero[1][j] && tablero[1][j] == tablero[2][j]) {
                return true;
            }
        }
        
        // Verificar diagonales
        if (tablero[0][0] != 0 && tablero[0][0] == tablero[1][1] && tablero[1][1] == tablero[2][2]) {
            return true;
        }
        if (tablero[0][2] != 0 && tablero[0][2] == tablero[1][1] && tablero[1][1] == tablero[2][0]) {
            return true;
        }
        
        return false;
    }
    
    private boolean tableroLleno() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (tablero[i][j] == 0) {
                    return false;
                }
            }
        }
        return true;
    }
    
    private void mostrarTablero() {
        System.out.println("\nTablero:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                char simbolo = ' ';
                if (tablero[i][j] == 1) simbolo = 'X';
                else if (tablero[i][j] == 2) simbolo = 'O';
                
                System.out.print(simbolo);
                if (j < 2) System.out.print("|");
            }
            System.out.println();
            if (i < 2) System.out.println("-+-+-");
        }
        System.out.println();
    }
    
    public static void main(String[] args) {
        TresEnRaya juego = new TresEnRaya();
        juego.jugar();
    }
}