package Teoricos_8;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.JPanel;

public class PanelDibujo extends JPanel {

    private Random aleatorio = new Random();

    private Milinea lineas[];
    private MiRectangulo rectangulos[];
    private MiOvalo ovalos[];

    public PanelDibujo() {
        setBackground(Color.WHITE);

        lineas = new Milinea[1 + aleatorio.nextInt(5)];
        rectangulos = new MiRectangulo[1 + aleatorio.nextInt(5)];
        ovalos = new MiOvalo[1 + aleatorio.nextInt(5)];

        for (int i = 0; i < lineas.length; i++) {
            int x1 = aleatorio.nextInt(300);
            int y1 = aleatorio.nextInt(300);
            int x2 = aleatorio.nextInt(300);
            int y2 = aleatorio.nextInt(300);
            Color c = new Color(aleatorio.nextInt(256), aleatorio.nextInt(256), aleatorio.nextInt(256));
            lineas[i] = new Milinea(x1, y1, x2, y2, c);
        }

        for (int i = 0; i < rectangulos.length; i++) {
            int x1 = aleatorio.nextInt(300);
            int y1 = aleatorio.nextInt(300);
            int x2 = aleatorio.nextInt(300);
            int y2 = aleatorio.nextInt(300);
            Color c = new Color(aleatorio.nextInt(256), aleatorio.nextInt(256), aleatorio.nextInt(256));
            boolean r = aleatorio.nextBoolean();
            rectangulos[i] = new MiRectangulo(x1, y1, x2, y2, c, r);
        }

        for (int i = 0; i < ovalos.length; i++) {
            int x1 = aleatorio.nextInt(300);
            int y1 = aleatorio.nextInt(300);
            int x2 = aleatorio.nextInt(300);
            int y2 = aleatorio.nextInt(300);
            Color c = new Color(aleatorio.nextInt(256), aleatorio.nextInt(256), aleatorio.nextInt(256));
            boolean r = aleatorio.nextBoolean();
            ovalos[i] = new MiOvalo(x1, y1, x2, y2, c, r);
        }
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (Milinea l : lineas)
            l.dibujar(g);

        for (MiRectangulo r : rectangulos)
            r.dibujar(g);

        for (MiOvalo o : ovalos)
            o.dibujar(g);
    }
}
