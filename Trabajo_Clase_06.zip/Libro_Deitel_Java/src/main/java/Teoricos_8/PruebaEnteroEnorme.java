package Teoricos_8;

public class PruebaEnteroEnorme {
    public static void main(String[] args) {
        EnteroEnorme n1 = new EnteroEnorme();
        EnteroEnorme n2 = new EnteroEnorme();
        
        n1.entrada("1234567890123456789012345678901234567890");
        n2.entrada("9876543210987654321098765432109876543210");
        
        System.out.print("n1 = "); n1.salida();
        System.out.print("n2 = "); n2.salida();
        
        System.out.printf("n1 es igual a n2: %b%n", n1.esIgualA(n2));
        System.out.printf("n1 es mayor que n2: %b%n", n1.esMayorQue(n2));
        System.out.printf("n1 es cero: %b%n", n1.esCero());
    }
}