package Teoricos_8;

import java.awt.Color;
import java.awt.Graphics;

public class MiRectangulo {
    private int x1, y1, x2, y2;
    private Color color;
    private boolean relleno;

    public MiRectangulo() {
        this(0, 0, 0, 0, Color.BLACK, false);
    }

    public MiRectangulo(int x1, int y1, int x2, int y2, Color color, boolean relleno) {
        setX1(x1);
        setY1(y1);
        setX2(x2);
        setY2(y2);
        setColor(color);
        setRelleno(relleno);
    }

    public void setX1(int x) { x1 = Math.max(0, x); }
    public void setY1(int y) { y1 = Math.max(0, y); }
    public void setX2(int x) { x2 = Math.max(0, x); }
    public void setY2(int y) { y2 = Math.max(0, y); }
    public void setColor(Color c) { color = c; }
    public void setRelleno(boolean r) { relleno = r; }

    public int getX1() { return x1; }
    public int getY1() { return y1; }
    public int getX2() { return x2; }
    public int getY2() { return y2; }
    public Color getColor() { return color; }
    public boolean isRelleno() { return relleno; }

    public int obtenerXSupIzq() { return Math.min(x1, x2); }
    public int obtenerYSupIzq() { return Math.min(y1, y2); }
    public int obtenerAnchura() { return Math.abs(x1 - x2); }
    public int obtenerAltura() { return Math.abs(y1 - y2); }

    public void dibujar(Graphics g) {
        g.setColor(getColor());
        int x = obtenerXSupIzq();
        int y = obtenerYSupIzq();
        int ancho = obtenerAnchura();
        int alto = obtenerAltura();

        if (isRelleno())
            g.fillRect(x, y, ancho, alto);
        else
            g.drawRect(x, y, ancho, alto);
    }
}
