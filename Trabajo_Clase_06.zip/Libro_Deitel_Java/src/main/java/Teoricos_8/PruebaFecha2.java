package Teoricos_8;

public class PruebaFecha2 {
    public static void main(String[] args) {
        Fecha2 f1 = new Fecha2(6, 15, 2023);
        Fecha2 f2 = new Fecha2("Junio", 15, 2023);
        Fecha2 f3 = new Fecha2(166, 2023);
        
        System.out.println("Formato MM/DD/AAAA: " + f1.formatoMMDDAAAA());
        System.out.println("Formato Mes DD, AAAA: " + f2.formatoMesDDAAAA());
        System.out.println("Formato DDD AAAA: " + f3.formatoDDDAAAA());
    }
}