package Teoricos_8;

public class Empleado1 {
	private String primerNombre;
	private String apellidoPaterno;
	private static int cuenta = 0; // número de objetos en memoria

	// inicializa empleado, suma 1 a la variable static cuenta e
	
	public Empleado1(String nombre, String apellido)
	{
	    primerNombre = nombre;
	    apellidoPaterno = apellido;

	    cuenta++; // incrementa la variable static cuenta de empleados
	    System.out.printf("Constructor de Empleado: %s %s; cuenta = %d\n",
	        primerNombre, apellidoPaterno, cuenta);
	} // fin de constructor de Empleado
	
	// confirma que se llamó a finalize, borra objeto
	protected void finalize()
	{
	    cuenta--; // decrementa la variable static cuenta de empleados
	    System.out.printf("Finalizador de Empleado: %s %s; cuenta = %d\n",
	        primerNombre, apellidoPaterno, cuenta);
	} 

	// obtiene el primer nombre
	public String obtenerPrimerNombre()
	{
	    return primerNombre;
	} 

	// obtiene el apellido paterno
	public String obtenerApellidoPaterno()
	{
	    return apellidoPaterno;
	} 

	// método static para obtener el valor de la variable static cuenta
	public static int obtenerCuenta()
	{
	    return cuenta;
	} 
}
