package Teoricos_8;

//la clase Teclado representa el teclado de un ATM
public class Teclado
{
 // no se han especificado atributos todavía

 // constructor sin argumentos
 public Teclado()
 {
 } // fin del constructor de Teclado sin argumentos

 // operaciones
 public int obtenerEntrada()
 {
     // Implementación básica usando Scanner para obtener entrada del usuario
     java.util.Scanner scanner = new java.util.Scanner(System.in);
     
     System.out.print("Por favor, ingrese un número: ");
     
     while (!scanner.hasNextInt()) {
         System.out.print("Entrada inválida. Por favor, ingrese un número entero: ");
         scanner.next(); // Limpiar el buffer
     }
     
     int entrada = scanner.nextInt();
     return entrada;
 } // fin del método obtenerEntrada
} // fin de la clase Teclado