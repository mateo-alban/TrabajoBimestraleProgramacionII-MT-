package Teoricos_8;

public class PruebaDatosPaquete{
    public static void main(String args[]){
        DatosPaquete datosPaquete = new DatosPaquete();
        
        // imprime la representación 
        System.out.printf("Después de instanciar:\n%s\n", datosPaquete);
        
        // modifica los datos con acceso
        datosPaquete.numero = 77;
        datosPaquete.cadena = "Adiós";
        
        // imprime la representación String de datosPaquete
        System.out.printf("\nDespués de modificar valores:\n%s\n", datosPaquete);
    } // fin de main
} // finPruebaDatosPaquete

// Clase con variables de instancia con acceso a nivel de paquete
class DatosPaquete
{
    int numero; // variable de instancia con acceso a nivel de paquete
    String cadena; // variable de instancia con acceso a nivel de paquete
    
 // constructor
    public DatosPaquete() {
        numero = 0;
        cadena = "Hola";
    }
    
    // método toString para representación String del objeto
    public String toString() {
        return String.format("numero: %d, cadena: %s", numero, cadena);
    }
} 