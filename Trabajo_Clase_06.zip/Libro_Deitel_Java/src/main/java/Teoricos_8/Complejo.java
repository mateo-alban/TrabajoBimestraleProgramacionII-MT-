package Teoricos_8;

public class Complejo {
    private double parteReal;
    private double parteImaginaria;
    
    public Complejo() {
        this(0.0, 0.0);
    }
    
    public Complejo(double real, double imaginaria) {
        this.parteReal = real;
        this.parteImaginaria = imaginaria;
    }
    
    public Complejo sumar(Complejo otro) {
        return new Complejo(
            this.parteReal + otro.parteReal,
            this.parteImaginaria + otro.parteImaginaria
        );
    }
    
    public Complejo restar(Complejo otro) {
        return new Complejo(
            this.parteReal - otro.parteReal,
            this.parteImaginaria - otro.parteImaginaria
        );
    }
    
    public void imprimir() {
        System.out.printf("(%.2f, %.2f)%n", parteReal, parteImaginaria);
    }
    
    public String toString() {
        return String.format("(%.2f, %.2f)", parteReal, parteImaginaria);
    }
}
