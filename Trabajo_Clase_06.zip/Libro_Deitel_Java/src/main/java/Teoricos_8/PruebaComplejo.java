package Teoricos_8;

public class PruebaComplejo {
    public static void main(String[] args) {
        Complejo c1 = new Complejo(3.5, 2.8);
        Complejo c2 = new Complejo(1.2, -4.3);
        
        System.out.print("c1 = "); c1.imprimir();
        System.out.print("c2 = "); c2.imprimir();
        
        Complejo suma = c1.sumar(c2);
        System.out.print("Suma = "); suma.imprimir();
        
        Complejo resta = c1.restar(c2);
        System.out.print("Resta = "); resta.imprimir();
    }
}