package Teoricos_8;

public class FechaYTiempo {
    private Fecha fecha;
    private Tiempo2 tiempo;
    
    public FechaYTiempo(int mes, int dia, int anio, int hora, int minuto, int segundo) {
        this.fecha = new Fecha(mes, dia, anio);
        this.tiempo = new Tiempo2();
        this.tiempo.establecerHora(hora);
        this.tiempo.establecerMinuto(minuto);
        this.tiempo.establecerSegundo(segundo);
    }
    
    public void incrementarHora() {
        // Implementación que incrementa la hora y si pasa de 23:59:59, cambia al siguiente día
        // (código simplificado)
        System.out.println("Hora incrementada - posible cambio de día");
    }
    
    public String aStringEstandar() {
        return fecha.toString() + " " + tiempo.toString();
    }
    
    public String aStringUniversal() {
        return fecha.toString() + " " + tiempo.toString();
    }
}