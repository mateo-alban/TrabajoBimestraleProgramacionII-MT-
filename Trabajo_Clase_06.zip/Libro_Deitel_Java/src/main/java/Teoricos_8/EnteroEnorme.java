package Teoricos_8;

public class EnteroEnorme {
    private static final int TAMANIO = 40;
    private int[] digitos;
    
    public EnteroEnorme() {
        digitos = new int[TAMANIO];
    }
    
    public void entrada(String numero) {
        if (numero.length() > TAMANIO) {
            throw new IllegalArgumentException("Número demasiado grande");
        }
        
        // Limpiar dígitos
        for (int i = 0; i < TAMANIO; i++) {
            digitos[i] = 0;
        }
        
        // Llenar desde el final
        int inicio = TAMANIO - numero.length();
        for (int i = 0; i < numero.length(); i++) {
            char c = numero.charAt(i);
            if (c < '0' || c > '9') {
                throw new IllegalArgumentException("Carácter inválido: " + c);
            }
            digitos[inicio + i] = c - '0';
        }
    }
    
    public void salida() {
        boolean imprimir = false;
        for (int i = 0; i < TAMANIO; i++) {
            if (digitos[i] != 0) {
                imprimir = true;
            }
            if (imprimir) {
                System.out.print(digitos[i]);
            }
        }
        if (!imprimir) {
            System.out.print("0");
        }
        System.out.println();
    }
    
    public EnteroEnorme sumar(EnteroEnorme otro) {
        EnteroEnorme resultado = new EnteroEnorme();
        int acarreo = 0;
        
        for (int i = TAMANIO - 1; i >= 0; i--) {
            int suma = this.digitos[i] + otro.digitos[i] + acarreo;
            resultado.digitos[i] = suma % 10;
            acarreo = suma / 10;
        }
        
        if (acarreo != 0) {
            throw new ArithmeticException("Desbordamiento en la suma");
        }
        
        return resultado;
    }
    
    public EnteroEnorme restar(EnteroEnorme otro) {
        EnteroEnorme resultado = new EnteroEnorme();
        int prestamo = 0;
        
        for (int i = TAMANIO - 1; i >= 0; i--) {
            int resta = this.digitos[i] - otro.digitos[i] - prestamo;
            if (resta < 0) {
                resta += 10;
                prestamo = 1;
            } else {
                prestamo = 0;
            }
            resultado.digitos[i] = resta;
        }
        
        if (prestamo != 0) {
            throw new ArithmeticException("Resultado negativo no soportado");
        }
        
        return resultado;
    }
    
    public boolean esIgualA(EnteroEnorme otro) {
        for (int i = 0; i < TAMANIO; i++) {
            if (this.digitos[i] != otro.digitos[i]) {
                return false;
            }
        }
        return true;
    }
    
    public boolean noEsIgualA(EnteroEnorme otro) {
        return !esIgualA(otro);
    }
    
    public boolean esMayorQue(EnteroEnorme otro) {
        for (int i = 0; i < TAMANIO; i++) {
            if (this.digitos[i] > otro.digitos[i]) {
                return true;
            } else if (this.digitos[i] < otro.digitos[i]) {
                return false;
            }
        }
        return false;
    }
    
    public boolean esMenorQue(EnteroEnorme otro) {
        return !esMayorQue(otro) && !esIgualA(otro);
    }
    
    public boolean esMayorOIgualA(EnteroEnorme otro) {
        return esMayorQue(otro) || esIgualA(otro);
    }
    
    public boolean esMenorOIgualA(EnteroEnorme otro) {
        return esMenorQue(otro) || esIgualA(otro);
    }
    
    public boolean esCero() {
        for (int i = 0; i < TAMANIO; i++) {
            if (digitos[i] != 0) {
                return false;
            }
        }
        return true;
    }
}