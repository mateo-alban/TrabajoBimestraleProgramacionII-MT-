package Teoricos_8;

public class PruebaEmpleado1 {

	public static void main(String[] args) {
		System.out.printf("Empleados antes de instanciar: %d\n",
			    Empleado1.obtenerCuenta());

			// crea dos Empleados; la cuenta debe ser 2
			Empleado1 e1 = new Empleado1("Susan", "Baker");
			Empleado1 e2 = new Empleado1("Bob", "Blue");

			// muestra que la cuenta es 2 después de crear dos Empleados
			System.out.println("\nEmpleados después de instanciar:");
			System.out.printf("mediante e1.obtenerCuenta(): %d\n", e1.obtenerCuenta());
			System.out.printf("mediante e2.obtenerCuenta(): %d\n", e2.obtenerCuenta());
			System.out.printf("mediante Empleado.obtenerCuenta(): %d\n",
			    Empleado1.obtenerCuenta());

			// obtiene los nombres de los Empleados
			System.out.printf("\nEmpleado 1: %s %s\nEmpleado 2: %s %s\n\n",
			    e1.obtenerPrimerNombre(), e1.obtenerApellidoPaterno(),
			    e2.obtenerPrimerNombre(), e2.obtenerApellidoPaterno());

			//Recoleccion de basura
			e1 = null;
			e2 = null;
			
			System.gc(); // pide que la recolección de basura se realice ahora

			// muestra la cuenta de Empleados después de llamar al recolector de basura;
			// la cuenta a mostrar puede ser 0, 1 o 2 dependiendo de si el recolector de
			// basura se ejecuta de inmediato, y del número de objetos Empleado recolectados
			System.out.printf("\nEmpleados después de System.gc(): %d\n",
			    Empleado1.obtenerCuenta());
			} 
}


