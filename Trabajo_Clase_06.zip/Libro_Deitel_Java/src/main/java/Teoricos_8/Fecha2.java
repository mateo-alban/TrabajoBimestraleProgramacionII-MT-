package Teoricos_8;

public class Fecha2 {
    private int mes;
    private int dia;
    private int anio;
    
    private static final String[] NOMBRES_MESES = {
        "", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    };
    
    private static final int[] DIAS_POR_MES = 
        {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    

	public Fecha2(int mes, int dia, int anio) {
        validarFecha(mes, dia, anio);
        this.mes = mes;
        this.dia = dia;
        this.anio = anio;
    }
    
    // Constructor para formato "Mes DD, AAAA"
    public Fecha2(String nombreMes, int dia, int anio) {
        int mes = obtenerNumeroMes(nombreMes);
        validarFecha(mes, dia, anio);
        this.mes = mes;
        this.dia = dia;
        this.anio = anio;
    }
    
    // Constructor para formato DDD AAAA
    public Fecha2(int diaDelAnio, int anio) {
        this.anio = anio;
        convertirDiaDelAnio(diaDelAnio, anio);
    }
    
    private void validarFecha(int mes, int dia, int anio) {
        if (mes < 1 || mes > 12) {
            throw new IllegalArgumentException("Mes inválido: " + mes);
        }
        
        int diasMaximos = DIAS_POR_MES[mes];
        if (mes == 2 && esBisiesto(anio)) {
            diasMaximos = 29;
        }
        
        if (dia < 1 || dia > diasMaximos) {
            throw new IllegalArgumentException("Día inválido: " + dia);
        }
        
        if (anio < 0) {
            throw new IllegalArgumentException("Año inválido: " + anio);
        }
    }
    
    private int obtenerNumeroMes(String nombreMes) {
        for (int i = 1; i < NOMBRES_MESES.length; i++) {
            if (NOMBRES_MESES[i].equalsIgnoreCase(nombreMes)) {
                return i;
            }
        }
        throw new IllegalArgumentException("Mes inválido: " + nombreMes);
    }
    
    private void convertirDiaDelAnio(int diaDelAnio, int anio) {
        if (diaDelAnio < 1 || diaDelAnio > (esBisiesto(anio) ? 366 : 365)) {
            throw new IllegalArgumentException("Día del año inválido: " + diaDelAnio);
        }
        
        int mes = 1;
        int diaRestante = diaDelAnio;
        
        for (int i = 1; i <= 12 && diaRestante > DIAS_POR_MES[i]; i++) {
            int diasEnMes = DIAS_POR_MES[i];
            if (i == 2 && esBisiesto(anio)) {
                diasEnMes = 29;
            }
            
            if (diaRestante > diasEnMes) {
                diaRestante -= diasEnMes;
                mes++;
            } else {
                break;
            }
        }
        
        this.mes = mes;
        this.dia = diaRestante;
    }
    
    private boolean esBisiesto(int anio) {
        return (anio % 400 == 0) || (anio % 4 == 0 && anio % 100 != 0);
    }
    
    public String formatoMMDDAAAA() {
        return String.format("%02d/%02d/%04d", mes, dia, anio);
    }
    
    public String formatoMesDDAAAA() {
        return String.format("%s %d, %04d", NOMBRES_MESES[mes], dia, anio);
    }
    
    public String formatoDDDAAAA() {
        int diaDelAnio = 0;
        for (int i = 1; i < mes; i++) {
            diaDelAnio += DIAS_POR_MES[i];
            if (i == 2 && esBisiesto(anio)) {
                diaDelAnio += 1;
            }
        }
        diaDelAnio += dia;
        return String.format("%03d %04d", diaDelAnio, anio);
    }
    
    public String toString() {
        return formatoMMDDAAAA();
    }
}