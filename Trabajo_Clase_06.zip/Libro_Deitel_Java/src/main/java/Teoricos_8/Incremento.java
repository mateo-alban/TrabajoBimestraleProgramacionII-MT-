package Teoricos_8;

public class Incremento{
	 private int total = 0; // el total de todos los incrementos
	 private final int INCREMENTO; // variable constante (sin inicializar)
	
	 // el constructor inicializa la variable de instancia
	 public Incremento( int valorIncremento ){
		 INCREMENTO = valorIncremento; 
	  } 
	 
	  // suma INCREMENTO al total
	  public void sumarIncrementoATotal() {
		  total += INCREMENTO;
	 } 
	  
	  public String toString() {
	   return String.format( "total = %d", total );
	 } 
}
