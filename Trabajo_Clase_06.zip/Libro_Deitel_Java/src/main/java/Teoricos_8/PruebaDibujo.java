package Teoricos_8;

import javax.swing.JFrame;

public class PruebaDibujo {
    public static void main(String args[]) {
        PanelDibujo panel = new PanelDibujo();
        JFrame application = new JFrame();

        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        application.add(panel);
        application.setSize(350, 350);
        application.setVisible(true);
    }
}
