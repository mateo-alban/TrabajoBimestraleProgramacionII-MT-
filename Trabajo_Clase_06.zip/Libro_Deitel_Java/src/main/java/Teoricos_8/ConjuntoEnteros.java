package Teoricos_8;

public class ConjuntoEnteros {
    private boolean[] conjunto;
    
    public ConjuntoEnteros() {
        conjunto = new boolean[101]; // 0-100
    }
    
    public ConjuntoEnteros union(ConjuntoEnteros otro) {
        ConjuntoEnteros resultado = new ConjuntoEnteros();
        for (int i = 0; i < conjunto.length; i++) {
            resultado.conjunto[i] = this.conjunto[i] || otro.conjunto[i];
        }
        return resultado;
    }
    
    public ConjuntoEnteros interseccion(ConjuntoEnteros otro) {
        ConjuntoEnteros resultado = new ConjuntoEnteros();
        for (int i = 0; i < conjunto.length; i++) {
            resultado.conjunto[i] = this.conjunto[i] && otro.conjunto[i];
        }
        return resultado;
    }
    
    public void insertarElemento(int k) {
        if (k >= 0 && k <= 100) {
            conjunto[k] = true;
        }
    }
    
    public void eliminarElemento(int m) {
        if (m >= 0 && m <= 100) {
            conjunto[m] = false;
        }
    }
    
    public String aStringConjunto() {
        StringBuilder sb = new StringBuilder();
        boolean vacio = true;
        
        for (int i = 0; i < conjunto.length; i++) {
            if (conjunto[i]) {
                sb.append(i).append(" ");
                vacio = false;
            }
        }
        
        return vacio ? "---" : sb.toString().trim();
    }
    
    public boolean esIgualA(ConjuntoEnteros otro) {
        for (int i = 0; i < conjunto.length; i++) {
            if (this.conjunto[i] != otro.conjunto[i]) {
                return false;
            }
        }
        return true;
    }
}