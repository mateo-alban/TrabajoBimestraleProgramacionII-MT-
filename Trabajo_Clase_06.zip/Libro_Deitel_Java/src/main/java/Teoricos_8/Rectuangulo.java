package Teoricos_8;

public class Rectangulo {
    private double x1, y1, x2, y2, x3, y3, x4, y4;
    
    public Rectangulo(double x1, double y1, double x2, double y2, 
                     double x3, double y3, double x4, double y4) {
        establecerCoordenadas(x1, y1, x2, y2, x3, y3, x4, y4);
    }
    
    private void establecerCoordenadas(double x1, double y1, double x2, double y2,
                                     double x3, double y3, double x4, double y4) {
        // Validar que estén en primer cuadrante y <= 20.0
        double[] xs = {x1, x2, x3, x4};
        double[] ys = {y1, y2, y3, y4};
        
        for (double x : xs) {
            if (x < 0 || x > 20.0) throw new IllegalArgumentException("Coordenada x fuera de rango");
        }
        for (double y : ys) {
            if (y < 0 || y > 20.0) throw new IllegalArgumentException("Coordenada y fuera de rango");
        }
        
        // Validar que formen un rectángulo (simplificado)
        this.x1 = x1; this.y1 = y1;
        this.x2 = x2; this.y2 = y2;
        this.x3 = x3; this.y3 = y3;
        this.x4 = x4; this.y4 = y4;
    }
    
    public double calcularLongitud() {
        double base1 = Math.abs(x2 - x1);
        double base2 = Math.abs(x4 - x3);
        return Math.max(base1, base2);
    }
    
    public double calcularAnchura() {
        double altura1 = Math.abs(y2 - y1);
        double altura2 = Math.abs(y4 - y3);
        return Math.min(altura1, altura2);
    }
    
    public double calcularPerimetro() {
        return 2 * (calcularLongitud() + calcularAnchura());
    }
    
    public double calcularArea() {
        return calcularLongitud() * calcularAnchura();
    }
    
    public boolean esCuadrado() {
        return Math.abs(calcularLongitud() - calcularAnchura()) < 0.0001;
    }
}