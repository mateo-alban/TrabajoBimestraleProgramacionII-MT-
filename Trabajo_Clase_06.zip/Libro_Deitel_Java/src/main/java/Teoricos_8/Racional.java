package Teoricos_8;

public class Racional {
    private int numerador;
    private int denominador;
    
    public Racional() {
        this(0, 1);
    }
    
    public Racional(int numerador, int denominador) {
        if (denominador == 0) {
            throw new IllegalArgumentException("Denominador no puede ser cero");
        }
        
        this.numerador = numerador;
        this.denominador = denominador;
        reducir();
    }
    
    private void reducir() {
        int mcd = mcd(Math.abs(numerador), Math.abs(denominador));
        numerador /= mcd;
        denominador /= mcd;
        
        if (denominador < 0) {
            numerador = -numerador;
            denominador = -denominador;
        }
    }
    
    private int mcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
    
    public Racional sumar(Racional otro) {
        int nuevoNumerador = this.numerador * otro.denominador + otro.numerador * this.denominador;
        int nuevoDenominador = this.denominador * otro.denominador;
        return new Racional(nuevoNumerador, nuevoDenominador);
    }
    
    public Racional restar(Racional otro) {
        int nuevoNumerador = this.numerador * otro.denominador - otro.numerador * this.denominador;
        int nuevoDenominador = this.denominador * otro.denominador;
        return new Racional(nuevoNumerador, nuevoDenominador);
    }
    
    public Racional multiplicar(Racional otro) {
        return new Racional(
            this.numerador * otro.numerador,
            this.denominador * otro.denominador
        );
    }
    
    public Racional dividir(Racional otro) {
        return new Racional(
            this.numerador * otro.denominador,
            this.denominador * otro.numerador
        );
    }
    
    public String aFormaFraccion() {
        return numerador + "/" + denominador;
    }
    
    public double aFormaDecimal() {
        return (double) numerador / denominador;
    }
    
    public String aFormaDecimal(int decimales) {
        return String.format("%." + decimales + "f", aFormaDecimal());
    }
    
    public String toString() {
        return aFormaFraccion();
    }
}