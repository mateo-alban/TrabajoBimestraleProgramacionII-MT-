package Teoricos_8;

public class PruebaLuzSemaforo {
    public static void main(String[] args) {
        System.out.println("Constantes de LuzSemaforo y sus duraciones:");
        for (LuzSemaforo luz : LuzSemaforo.values()) {
            System.out.printf("%s: %d segundos%n", luz, luz.getDuracion());
        }
    }
}