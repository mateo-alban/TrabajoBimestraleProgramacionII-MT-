package Teoricos_8;

import java.awt.Color;
import java.awt.Graphics;

public class Milinea {
    private int x1;
    private int y1;
    private int x2;
    private int y2;
    private Color micolor;

    public Milinea() {
        this(0, 0, 0, 0, Color.BLACK);
    }

    public Milinea(int x1, int y1, int x2, int y2, Color color) {
        setX1(x1);
        setY1(y1);
        setX2(x2);
        setY2(y2);
        this.micolor = color;
    }

    public void setX1(int x) { this.x1 = Math.max(0, x); }
    public void setY1(int y) { this.y1 = Math.max(0, y); }
    public void setX2(int x) { this.x2 = Math.max(0, x); }
    public void setY2(int y) { this.y2 = Math.max(0, y); }
    public void setColor(Color c) { this.micolor = c; }

    public int getX1() { return x1; }
    public int getY1() { return y1; }
    public int getX2() { return x2; }
    public int getY2() { return y2; }
    public Color getColor() { return micolor; }

    public void dibujar(Graphics g) {
        g.setColor(micolor);
        g.drawLine(getX1(), getY1(), getX2(), getY2());
    }
}
