package PackageAlternativo_8;

public class Tiempo1{
    private int hora;   
    private int minuto;  
    private int segundo; 

    // establece un nuevo valor de tiempo, usando la hora universal; asegura que
   
    public void establecerTiempo(int h, int m, int s)
    {
        setHora(((h >= 0 && h < 24) ? h : 0));    // valida la hora
        setMinuto(((m >= 0 && m < 60) ? m : 0));  // valida el minuto
        setSegundo(((s >= 0 && s < 60) ? s : 0)); // valida el segundo
    } 

    // convierte a objeto String en formato de hora universal (HH:MM:SS)
    public String aStringUniversal() {
        return String.format("%02d:%02d:%02d", getHora(), getMinuto(), getSegundo());
    } 

    // convierte a objeto String en formato de hora estándar (H:MM:SS AM o PM)
    public String toString() {
        return String.format("%d:%02d:%02d %s",
            ((getHora() == 0 || getHora() == 12) ? 12 : getHora() % 12),
            getMinuto(), getSegundo(), (getHora() < 12 ? "AM" : "PM"));
    }

	public int getHora() {
		return hora;
	}

	public void setHora(int hora) {
		this.hora = hora;
	}

	public int getMinuto() {
		return minuto;
	}

	public void setMinuto(int minuto) {
		this.minuto = minuto;
	}

	public int getSegundo() {
		return segundo;
	}

	public void setSegundo(int segundo) {
		this.segundo = segundo;
	}

	public char[] crearString() {
		// TODO Auto-generated method stub
		return null;
	} 
} 