package PackageAlternativo_8;

//Programa de prueba
public class PruebaFecha {
 public static void main(String[] args) {
     // Prueba a) Cambio al siguiente mes
     System.out.println("Prueba a) Cambio al siguiente mes:");
     Fecha fecha1 = new Fecha(6, 30, 2023);
     System.out.println("Fecha inicial: " + fecha1);
     fecha1.siguienteDia();
     System.out.println("Siguiente día: " + fecha1);
     
     // Prueba b) Cambio al siguiente año
     System.out.println("\nPrueba b) Cambio al siguiente año:");
     Fecha fecha2 = new Fecha(12, 31, 2023);
     System.out.println("Fecha inicial: " + fecha2);
     fecha2.siguienteDia();
     System.out.println("Siguiente día: " + fecha2);
 }
}