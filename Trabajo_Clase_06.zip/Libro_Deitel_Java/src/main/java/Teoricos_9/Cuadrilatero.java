package Teoricos_9;

public class Cuadrilatero {
    private double x1, y1, x2, y2, x3, y3, x4, y4;
    
    public Cuadrilatero(double x1, double y1, double x2, double y2,
                       double x3, double y3, double x4, double y4) {
        this.x1 = x1; this.y1 = y1;
        this.x2 = x2; this.y2 = y2;
        this.x3 = x3; this.y3 = y3;
        this.x4 = x4; this.y4 = y4;
    }
    
    // Getters para las coordenadas
    public double getX1() { return x1; }
    public double getY1() { return y1; }
    public double getX2() { return x2; }
    public double getY2() { return y2; }
    public double getX3() { return x3; }
    public double getY3() { return y3; }
    public double getX4() { return x4; }
    public double getY4() { return y4; }
    
    // Método para calcular área (genérico para cualquier cuadrilátero)
    public double calcularArea() {
        // Usando la fórmula del área de un cuadrilátero irregular
        // Fórmula: Área = 1/2 * |(x1y2 + x2y3 + x3y4 + x4y1) - (y1x2 + y2x3 + y3x4 + y4x1)|
        double suma1 = (x1 * y2) + (x2 * y3) + (x3 * y4) + (x4 * y1);
        double suma2 = (y1 * x2) + (y2 * x3) + (y3 * x4) + (y4 * x1);
        return Math.abs(suma1 - suma2) / 2.0;
    }
    
    // Método para calcular perímetro
    public double calcularPerimetro() {
        double lado1 = calcularDistancia(x1, y1, x2, y2);
        double lado2 = calcularDistancia(x2, y2, x3, y3);
        double lado3 = calcularDistancia(x3, y3, x4, y4);
        double lado4 = calcularDistancia(x4, y4, x1, y1);
        return lado1 + lado2 + lado3 + lado4;
    }
    
    // Método auxiliar para calcular distancia entre dos puntos
    protected double calcularDistancia(double x1, double y1, double x2, double y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }
    
    @Override
    public String toString() {
        return String.format("Cuadrilátero con vértices: (%.2f,%.2f), (%.2f,%.2f), (%.2f,%.2f), (%.2f,%.2f)", 
                           x1, y1, x2, y2, x3, y3, x4, y4);
    }
}