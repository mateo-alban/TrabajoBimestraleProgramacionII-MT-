package Teoricos_9;

public class Paralelogramo extends Cuadrilatero {
    public Paralelogramo(double x1, double y1, double x2, double y2,
                        double x3, double y3, double x4, double y4) {
        super(x1, y1, x2, y2, x3, y3, x4, y4);
    }
    
    @Override
    public double calcularArea() {
        double base = Math.abs(getX2() - getX1());
        double altura = Math.abs(getY3() - getY1());
        return base * altura;
    }
}