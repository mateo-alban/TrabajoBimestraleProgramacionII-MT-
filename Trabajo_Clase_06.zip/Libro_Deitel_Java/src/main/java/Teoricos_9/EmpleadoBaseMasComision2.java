package Teoricos_9;

public class EmpleadoBaseMasComision2 extends EmpleadoPorComision{
    private double salarioBase; // salario base por semana

    // constructor con seis argumentos
    public EmpleadoBaseMasComision2(String nombre, String apellido,
                                   String nss, double ventas, double tarifa, double salario) {
        // llamada explícita al constructor de la superclase EmpleadoPorComision
        super(nombre, apellido, nss, ventas, tarifa);
        establecerSalarioBase(salario); // valida y almacena el salario base
    } 

    // establecer salario base
    public void establecerSalarioBase(double salario) {
        salarioBase = (salario < 0.0) ? 0.0 : salario;
    } // fin del método establecerSalarioBase

    // 
    public double obtenerSalarioBase() {
        return salarioBase;
    } // fin del método obtenerSalarioBase

    //
    public double ingresos() {
        // Usar los métodos públicos de la superclase para acceder a los datos privados
        return salarioBase + (obtenerTarifaComision() * obtenerVentasBrutas());
    }
    public String toString() {
    
    return String.format(
    	    "%s: %s %s\n%s: %s\n%s: %.2f\n%s: %.2f\n%s: %.2f",
    	    "empleado por comision con sueldo base", primerNombre, apellidoPaterno,
    	    "numero de seguro social", numeroSeguroSocial,
    	    "ventas brutas", ventasBrutas, "tarifa de comision", tarifaComision,
    	    "salario base", salarioBase);
    	} 
} 