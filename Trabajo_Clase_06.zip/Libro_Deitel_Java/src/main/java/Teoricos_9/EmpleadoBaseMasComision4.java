package Teoricos_9;

public class EmpleadoBaseMasComision4 extends EmpleadoPorComision3
{
    private double salarioBase; 

    // constructor con seis argumentos
    public EmpleadoBaseMasComision4( String nombre, String apellido, String nss, 
    		double ventas, double tarifa, double salario ){
        super( nombre, apellido, nss, ventas, tarifa );
        establecerSalarioBase( salario ); // valida y almacena el salario base
    } 

    // establece el salario base
    public void establecerSalarioBase( double salario )
    {
        salarioBase = ( salario < 0.0 ) ? 0.0 : salario;
    } 
    // devuelve el salario base
    public double obtenerSalarioBase()
    {
        return salarioBase;
    } 

    // calcula los ingresos
    public double ingresos()
    {
        return obtenerSalarioBase() + super.ingresos();
    } 

    // devuelve representación String de EmpleadoBaseMasComision4
    public String toString()
    {
        return String.format("%s %s\n%s: %.2f", "con sueldo base",
            super.toString(), "sueldo base", obtenerSalarioBase());
    } 
} 