package Teoricos_9;

public class Cuadrado extends Rectangulo {
    public Cuadrado(double x1, double y1, double lado) {
        super(x1, y1, x1 + lado, y1, x1 + lado, y1 + lado, x1, y1 + lado);
    }
    
    @Override
    public double calcularArea() {
        double lado = Math.abs(getX2() - getX1());
        return lado * lado;
    }
}