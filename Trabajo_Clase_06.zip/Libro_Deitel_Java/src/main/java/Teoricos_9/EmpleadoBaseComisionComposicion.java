package Teoricos_9;

public class EmpleadoBaseComisionComposicion {
    private EmpleadoPorComision3 empleadoComision;
    private double salarioBase;

    public EmpleadoBaseComisionComposicion(String nombre, String apellido, String nss, 
                                            double ventas, double tarifa, double salario) {
        this.empleadoComision = new EmpleadoPorComision3(nombre, apellido, nss, ventas, tarifa);
        establecerSalarioBase(salario);
    }

    public void establecerSalarioBase(double salario) {
        salarioBase = (salario < 0.0) ? 0.0 : salario;
    }

    public double obtenerSalarioBase() {
        return salarioBase;
    }

    public double ingresos() {
        return salarioBase + empleadoComision.ingresos();
    }

    // Métodos delegados para acceder a los datos del empleado por comisión
    public String obtenerPrimerNombre() {
        return empleadoComision.obtenerPrimerNombre();
    }

    public String obtenerApellidoPaterno() {
        return empleadoComision.obtenerApellidoPaterno();
    }

    public String obtenerNumeroSeguroSocial() {
        return empleadoComision.obtenerNumeroSeguroSocial();
    }

    public double obtenerVentasBrutas() {
        return empleadoComision.obtenerVentasBrutas();
    }

    public double obtenerTarifaComision() {
        return empleadoComision.obtenerTarifaComision();
    }

    public String toString() {
        return String.format("%s\n%s: %.2f", 
            empleadoComision.toString(), 
            "sueldo base", salarioBase);
    }
}