package Teoricos_9;

public class PruebaEmpleadosBaseMasComision3 {

	public static void main(String[] args) {
		
		EmpleadoBaseMasComision3 empleado =
	            new EmpleadoBaseMasComision3(
	                "Bob", "Lewis", "333-33-3333", 5000, .04, 300 );

	        // obtiene datos del empleado por comision con sueldo base

	        // Figura 9.11 | Miembros protected de la superclase, heredados en la subclase EmpleadoBaseMasComision3.

	        System.out.println("Informacion del empleado, obtenida por los metodos establecer: \n" );
	        System.out.printf("%s %s\n", "El primer nombre es", empleado.obtenerPrimerNombre());
	        System.out.printf("%s %s\n", "El apellido es", empleado.obtenerApellidoPaterno());
	        System.out.printf("%s %s\n", "El numero seguro social es", empleado.obtenerNumeroSeguroSocial());
	        System.out.printf("%s %.2f\n", "Las ventas brutas son",empleado.obtenerVentasBrutas());
	        System.out.printf("%s %.2f\n", "La tarifa de comision es", empleado.obtenerTarifaComision());empleado.obtenerSalarioBase();
	        
	        empleado.establecerSalarioBase( 1000 ); // establece el salario base

	        System.out.printf("\n%s:\n\n%s\n", "Informacion actualizada del empleado, obtenida por toString",empleado.toString() );
	}	

}
