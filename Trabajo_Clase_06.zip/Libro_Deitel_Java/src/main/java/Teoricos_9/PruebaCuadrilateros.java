package Teoricos_9;

public class PruebaCuadrilateros {
    public static void main(String[] args) {
        Cuadrado cuadrado = new Cuadrado(0, 0, 5);
        Rectangulo rectangulo = new Rectangulo(0, 0, 6, 0, 6, 4, 0, 4);
        Trapezoide trapezoide = new Trapezoide(0, 0, 8, 0, 6, 4, 2, 4);
        
        System.out.printf("Área del cuadrado: %.2f%n", cuadrado.calcularArea());
        System.out.printf("Área del rectángulo: %.2f%n", rectangulo.calcularArea());
        System.out.printf("Área del trapezoide: %.2f%n", trapezoide.calcularArea());
    }
}